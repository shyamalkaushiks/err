package in.inueon.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.inueon.Model.Tourist;

public interface IamDao extends JpaRepository<Tourist, Integer> {

}
