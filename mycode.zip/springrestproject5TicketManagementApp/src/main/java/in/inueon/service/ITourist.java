package in.inueon.service;

import in.inueon.Model.Tourist;

public interface ITourist {
public String savedetails(Tourist tourist);
}
