package in.inueon.service;

import org.springframework.beans.factory.annotation.Autowired;

import in.inueon.Model.Tourist;
import in.inueon.dao.IamDao;

public class Itouristimpl implements ITourist{
@Autowired
private IamDao res;
	@Override
	public String savedetails(Tourist tourist) {
		// TODO Auto-generated method stub
		  Integer r =res.save(tourist).getTid();
		  String response="data is saved in db at id"+r;
		return response;
	}

}
