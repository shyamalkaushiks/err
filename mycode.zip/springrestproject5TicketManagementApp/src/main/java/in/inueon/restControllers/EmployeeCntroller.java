package in.inueon.restControllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.inueon.Model.Tourist;
import in.inueon.service.ITourist;
@RestController
public class EmployeeCntroller {
@Autowired
private ITourist service;

@GetMapping("/r")
public String Helloe()
{
	return "namaste";
}
 @PostMapping("/register")
	public ResponseEntity<String> addtourist(@RequestBody Tourist tourist)
	{
	try
	{
	  String r2=service.savedetails(tourist);     
	  return new  ResponseEntity<String>(r2,HttpStatus.OK);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		return new  ResponseEntity<String>("i caugth by error",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	}
	
}
