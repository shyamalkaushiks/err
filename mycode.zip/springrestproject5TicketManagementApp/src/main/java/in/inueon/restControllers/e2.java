package in.inueon.restControllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.inueon.Model.Tourist;
import in.inueon.service.ITourist;
@RestController
@RequestMapping("/he")
public class e2 {
@GetMapping("/h3")
public String Hello()
{
	return "bmj";
}
}
